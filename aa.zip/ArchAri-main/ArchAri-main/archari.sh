sh archtitus.sh
